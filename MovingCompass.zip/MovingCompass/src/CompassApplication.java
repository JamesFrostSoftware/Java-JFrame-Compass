public class CompassApplication {
    public static void main(String[] args) {
        CompassJFrame CJF = new CompassJFrame();
    }
}
